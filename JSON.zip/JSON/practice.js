//Q1. counting frequencies of an array

// let arr1 = [4, 2, 3, 4, 3, 2, 1, 3, 2];
// let freq = {};

// for (let num of arr1) {
//   freq[num] = (freq[num] || 0) + 1;
// }

// console.log(freq);


// let Highlightt=()=>{
// let a=document.querySelector("#high")
// a.style.color="yellow"
    
// }
 function multiply(a,b){
    return a*b
 }
var add=function(a,b){
    return a+b
}
console.log(multiply(2,3));
console.log(add(2,3));